import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
class SettingsService extends ChangeNotifier{
  String language='both'; bool voice=true,music=false,dark=false,reducedMotion=false; int dailyMinutes=10; String difficulty='easy';
  Future<void> load()async{final s=await SharedPreferences.getInstance();language=s.getString('set_lang')??'both';voice=s.getBool('voice')??true;music=s.getBool('music')??false;dark=s.getBool('dark')??false;reducedMotion=s.getBool('reduced')??false;dailyMinutes=s.getInt('daily')??10;difficulty=s.getString('difficulty')??'easy';notifyListeners();}
  Future<void> save()async{final s=await SharedPreferences.getInstance();await s.setString('set_lang',language);await s.setBool('voice',voice);await s.setBool('music',music);await s.setBool('dark',dark);await s.setBool('reduced',reducedMotion);await s.setInt('daily',dailyMinutes);await s.setString('difficulty',difficulty);notifyListeners();}
}
