import 'package:flutter_tts/flutter_tts.dart';
class AudioService { final FlutterTts _tts=FlutterTts(); Future<void> speak(String text,String lang) async {await _tts.stop();await _tts.setLanguage(lang=='ar'?'ar-SA':'en-US');await _tts.setSpeechRate(.42);await _tts.speak(text);} Future<void> stop()=>_tts.stop(); }
