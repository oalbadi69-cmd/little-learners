import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ChildProfile {
  final String id, name, avatar, language;
  final int age;
  const ChildProfile({required this.id,required this.name,required this.avatar,required this.age,required this.language});
  Map<String,dynamic> toJson()=>{'id':id,'name':name,'avatar':avatar,'age':age,'language':language};
  factory ChildProfile.fromJson(Map<String,dynamic> j)=>ChildProfile(id:j['id'],name:j['name'],avatar:j['avatar'],age:j['age'],language:j['language']);
}
class ProfileService extends ChangeNotifier {
  List<ChildProfile> profiles=[]; String? activeId;
  ChildProfile? get active { for(final p in profiles){if(p.id==activeId)return p;} return profiles.isEmpty?null:profiles.first; }
  Future<void> load() async {final s=await SharedPreferences.getInstance(); profiles=(s.getStringList('profiles')??[]).map((x)=>ChildProfile.fromJson(jsonDecode(x))).toList();activeId=s.getString('active_profile');notifyListeners();}
  Future<void> add(String name,String avatar,int age,String language) async {final p=ChildProfile(id:DateTime.now().microsecondsSinceEpoch.toString(),name:name.trim().isEmpty?'بطل صغير':name.trim(),avatar:avatar,age:age,language:language);profiles.add(p);activeId=p.id;await _save();}
  Future<void> select(String id) async {activeId=id;await _save();}
  Future<void> _save() async {final s=await SharedPreferences.getInstance();await s.setStringList('profiles',profiles.map((p)=>jsonEncode(p.toJson())).toList());if(activeId!=null)await s.setString('active_profile',activeId!);notifyListeners();}
}
