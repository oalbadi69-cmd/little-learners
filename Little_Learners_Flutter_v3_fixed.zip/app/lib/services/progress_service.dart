import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/learning_models.dart';
class ProgressService extends ChangeNotifier {
  ChildProgress data=ChildProgress();
  Future<void> load() async { final p=await SharedPreferences.getInstance(); data=ChildProgress(stars:p.getInt('stars')??0,attempts:p.getInt('attempts')??0,correct:p.getInt('correct')??0,practiced:(p.getStringList('practiced')??[]).toSet()); notifyListeners(); }
  Future<void> award(String id,{bool correct=true,int stars=1}) async {data.attempts++; if(correct){data.correct++;data.stars+=stars;} data.practiced.add(id); final p=await SharedPreferences.getInstance(); await p.setInt('stars',data.stars);await p.setInt('attempts',data.attempts);await p.setInt('correct',data.correct);await p.setStringList('practiced',data.practiced.toList());notifyListeners();}
  Future<void> reset() async {final p=await SharedPreferences.getInstance();await p.clear();data=ChildProgress();notifyListeners();}
}
