class LearningWord {
  final String en, ar, emoji;
  const LearningWord(this.en, this.ar, this.emoji);
}
class LetterItem {
  final String id, language, letter, lower, name, sound;
  final List<LearningWord> words;
  const LetterItem({required this.id,required this.language,required this.letter,required this.lower,required this.name,required this.sound,required this.words});
}
class ChildProgress {
  int stars, attempts, correct;
  final Set<String> practiced;
  ChildProgress({this.stars=0,this.attempts=0,this.correct=0,Set<String>? practiced}):practiced=practiced??{};
  double get accuracy=>attempts==0?0:correct/attempts;
}
