import '../models/learning_models.dart';
const englishAlphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ';
const arabicAlphabet=['ا','ب','ت','ث','ج','ح','خ','د','ذ','ر','ز','س','ش','ص','ض','ط','ظ','ع','غ','ف','ق','ك','ل','م','ن','هـ','و','ي'];
const _enWords=<String,List<LearningWord>>{
'A':[LearningWord('Apple','تُفَّاح','🍎'),LearningWord('Ant','نَمْلَة','🐜'),LearningWord('Airplane','طَائِرَة','✈️')],
'B':[LearningWord('Bear','دُبّ','🐻'),LearningWord('Ball','كُرَة','⚽'),LearningWord('Banana','مَوْز','🍌')],
'C':[LearningWord('Cat','قِطَّة','🐱'),LearningWord('Car','سَيَّارَة','🚗'),LearningWord('Cake','كَعْكَة','🍰')],
'D':[LearningWord('Dog','كَلْب','🐶'),LearningWord('Duck','بَطَّة','🦆'),LearningWord('Door','بَاب','🚪')],
'E':[LearningWord('Elephant','فِيل','🐘'),LearningWord('Egg','بَيْضَة','🥚'),LearningWord('Earth','الأَرْض','🌍')],
'F':[LearningWord('Fish','سَمَكَة','🐟'),LearningWord('Flower','زَهْرَة','🌸'),LearningWord('Fox','ثَعْلَب','🦊')],
'G':[LearningWord('Grapes','عِنَب','🍇'),LearningWord('Goat','مَاعِز','🐐'),LearningWord('Gift','هَدِيَّة','🎁')],
'H':[LearningWord('Horse','حِصَان','🐴'),LearningWord('House','مَنْزِل','🏠'),LearningWord('Heart','قَلْب','❤️')],
'I':[LearningWord('Ice','ثَلْج','🧊'),LearningWord('Island','جَزِيرَة','🏝️'),LearningWord('Ice cream','آيْس كْرِيم','🍦')],
'J':[LearningWord('Juice','عَصِير','🧃'),LearningWord('Jellyfish','قِنْدِيل البَحْر','🪼'),LearningWord('Jeans','بِنْطَال','👖')],
'K':[LearningWord('Kite','طَائِرَة وَرَقِيَّة','🪁'),LearningWord('Key','مِفْتَاح','🔑'),LearningWord('Kiwi','كِيوِي','🥝')],
'L':[LearningWord('Lion','أَسَد','🦁'),LearningWord('Lemon','لَيْمُون','🍋'),LearningWord('Leaf','وَرَقَة','🍃')],
'M':[LearningWord('Monkey','قِرْد','🐒'),LearningWord('Moon','قَمَر','🌙'),LearningWord('Milk','حَلِيب','🥛')],
'N':[LearningWord('Nest','عُشّ','🪹'),LearningWord('Nose','أَنْف','👃'),LearningWord('Notebook','دَفْتَر','📓')],
'O':[LearningWord('Orange','بُرْتُقَال','🍊'),LearningWord('Octopus','أُخْطُبُوط','🐙'),LearningWord('Owl','بُومَة','🦉')],
'P':[LearningWord('Panda','بَانْدَا','🐼'),LearningWord('Pear','كُمَّثْرَى','🍐'),LearningWord('Pencil','قَلَم','✏️')],
'Q':[LearningWord('Queen','مَلِكَة','👸'),LearningWord('Question','سُؤَال','❓'),LearningWord('Quilt','لِحَاف','🛏️')],
'R':[LearningWord('Rabbit','أَرْنَب','🐰'),LearningWord('Rainbow','قَوْس قُزَح','🌈'),LearningWord('Robot','رُوبُوت','🤖')],
'S':[LearningWord('Sun','شَمْس','☀️'),LearningWord('Star','نَجْمَة','⭐'),LearningWord('Strawberry','فَرَاوِلَة','🍓')],
'T':[LearningWord('Tiger','نَمِر','🐯'),LearningWord('Tree','شَجَرَة','🌳'),LearningWord('Train','قِطَار','🚆')],
'U':[LearningWord('Umbrella','مِظَلَّة','☂️'),LearningWord('Unicorn','وَحِيد القَرْن','🦄'),LearningWord('Up','أَعْلَى','⬆️')],
'V':[LearningWord('Van','شَاحِنَة صَغِيرَة','🚐'),LearningWord('Violin','كَمَان','🎻'),LearningWord('Volcano','بُرْكَان','🌋')],
'W':[LearningWord('Whale','حُوت','🐋'),LearningWord('Water','مَاء','💧'),LearningWord('Watch','سَاعَة','⌚')],
'X':[LearningWord('Xylophone','إِكْسِيلُوفُون','🎼'),LearningWord('X-ray','أَشِعَّة','🩻'),LearningWord('Xerus','سِنْجَاب أَرْضِي','🐿️')],
'Y':[LearningWord('Yak','يَاك','🐂'),LearningWord('Yarn','خَيْط','🧶'),LearningWord('Yellow','أَصْفَر','🟡')],
'Z':[LearningWord('Zebra','حِمَار وَحْشِي','🦓'),LearningWord('Zoo','حَدِيقَة حَيَوَان','🦁'),LearningWord('Zipper','سَحَّاب','🤐')],};
final englishLetters=englishAlphabet.split('').map((x)=>LetterItem(id:'en_$x',language:'en',letter:x,lower:x.toLowerCase(),name:x,sound:x.toLowerCase(),words:_enWords[x]!)).toList(growable:false);
final arabicLetters=arabicAlphabet.asMap().entries.map((e)=>LetterItem(id:'ar_${e.key}',language:'ar',letter:e.value,lower:e.value,name:e.value,sound:e.value,words:[LearningWord('${e.value}َ','حرف ${e.value}','⭐'),LearningWord('${e.value}ُ','صوت ${e.value}','🎈'),LearningWord('${e.value}ِ','نتعلم ${e.value}','📚')])).toList(growable:false);
void validateContent(){if(englishLetters.map((e)=>e.letter).join()!=englishAlphabet)throw StateError('English alphabet incomplete');if(arabicLetters.map((e)=>e.letter).join('|')!=arabicAlphabet.join('|'))throw StateError('Arabic alphabet incomplete');final ids=[...englishLetters,...arabicLetters].map((e)=>e.id).toList();if(ids.toSet().length!=ids.length)throw StateError('Duplicate IDs');if([...englishLetters,...arabicLetters].any((e)=>e.words.length<3))throw StateError('Each letter needs 3 words');}
