import 'package:flutter/material.dart';
import 'app/little_learners_app.dart';
import 'content/alphabet_data.dart';
void main(){WidgetsFlutterBinding.ensureInitialized();validateContent();runApp(const LittleLearnersApp());}
