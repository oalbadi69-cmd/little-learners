# Little Learners – الحروف والكلمات

Flutter bilingual early-learning application for ages 3–7.

## Implemented in this build
- Arabic + English alphabets with content validation
- Child profiles and avatars
- Today's Learning / smart next-item selection
- Letter and word learning with TTS
- Touch tracing/free drawing foundation
- Coloring canvas
- Animals, numbers 0–20, colors, shapes, words and sentences
- Quiz, memory, listening, sequence, word-building and sentence games
- Stars, accuracy, progress and achievements stored locally
- Parent gate + parent learning summary
- Settings for learning language, voice/music preference, reduced motion and daily duration
- Offline local progress storage

## Android APK cloud build
Push this repository to GitHub. The included `.github/workflows/android-apk.yml` creates the missing platform scaffolding with `flutter create`, installs dependencies, runs tests, builds a release APK, and uploads it as an artifact.

The generated APK artifact is `app-release.apk`.

## Important production roadmap
This source is a functional application build, but commercial App Store/Play Store release still requires signed release identities, store metadata/privacy disclosures, device QA, and replacing TTS/emoji fallbacks with the final licensed/recorded media pack where desired.
