import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:little_learners/app/little_learners_app.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  setUp(() {
    SharedPreferences.setMockInitialValues({});
    TestDefaultBinaryMessengerBinding.instance.defaultBinaryMessenger
        .setMockMethodCallHandler(const MethodChannel('flutter_tts'), (_) async => 1);
  });
  testWidgets('first launch creates a child profile and opens home', (tester) async {
    await tester.pumpWidget(const LittleLearnersApp());
    await tester.pump(const Duration(seconds: 1));
    await tester.pumpAndSettle();
    expect(find.text('Little Learners'), findsOneWidget);
    await tester.tap(find.text('ابدأ • Start'));
    await tester.pumpAndSettle();
    expect(find.byType(ProfileScreen), findsOneWidget);
    await tester.enterText(find.byType(TextField), 'Omar');
    await tester.ensureVisible(find.text('حفظ وابدأ • Save & Start'));
    await tester.tap(find.text('حفظ وابدأ • Save & Start'));
    await tester.pumpAndSettle();
    expect(find.byType(HomeScreen), findsOneWidget);
    expect(profiles.active?.name, 'Omar');
    expect(tester.takeException(), isNull);
  });
}
