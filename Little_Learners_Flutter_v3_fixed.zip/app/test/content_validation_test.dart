import 'package:flutter_test/flutter_test.dart';
import 'package:little_learners/content/alphabet_data.dart';
void main(){test('all required alphabets and minimum content exist',(){validateContent();expect(englishLetters.length,26);expect(arabicLetters.length,28);expect(englishLetters.every((e)=>e.words.length>=3),true);expect(arabicLetters.every((e)=>e.words.length>=3),true);});}
